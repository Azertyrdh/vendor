<?php

return [
    'Names' => [
        'BOB' => [
            'Bs',
            'Boliviano',
        ],
        'PEN' => [
            'PEN',
            'Sol Peruano',
        ],
    ],
];
