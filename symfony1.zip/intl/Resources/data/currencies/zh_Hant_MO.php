<?php

return [
    'Names' => [
        'MOP' => [
            'MOP$',
            '澳門元',
        ],
    ],
];
