<?php

return [
    'Names' => [
        'BBD' => [
            '$',
            'Barbadian Dollar',
        ],
    ],
];
