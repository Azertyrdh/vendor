<?php

return [
    'Names' => [
        'LKR' => [
            'Rs.',
            'இலங்கை ரூபாய்',
        ],
    ],
];
