<?php

return [
    'Names' => [
        'CDF' => [
            'FC',
            'franc congolais',
        ],
    ],
];
