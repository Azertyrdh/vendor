<?php

return [
    'Names' => [
        'SDG' => [
            'SDG',
            'جنيه سوداني',
        ],
    ],
];
