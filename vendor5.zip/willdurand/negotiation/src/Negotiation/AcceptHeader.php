<?php

namespace Negotiation;

interface AcceptHeader
{
}
