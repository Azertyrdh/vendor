PSR Event Dispatcher
====================

This repository holds the interfaces related to [PSR-14](http://www.php-fig.org/psr/psr-14/).

Note that this is not an Event Dispatcher implementation of its own. It is merely interfaces that describe the components of an Event Dispatcher.  See the specification for more details.
