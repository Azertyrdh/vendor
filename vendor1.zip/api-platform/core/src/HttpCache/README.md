# API Platform - HTTP Cache

HTTP Cache support.

## Resources


