# API Platform - Doctrine Common

Common files used by api-platform/doctrine-orm and api-platform/doctrine-odm

## Resources


