# API Platform - Elasticsearch

Elasticsearch Support.

## Resources


